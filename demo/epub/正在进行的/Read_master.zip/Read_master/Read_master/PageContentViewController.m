//
//  PageContentViewController.m
//  Read_master
//
//  Created by 吴小闯 on 2020/4/18.
//  Copyright © 2020 吴小闯. All rights reserved.
//

#import "PageContentViewController.h"
#import "TextViewController.h"
#import <objc/runtime.h>
#import "NSString+HTML.h"
#import "LSYCatalogViewController.h"
#import "LSYMenuView.h"
#import "UIImage+ImageEffects.h"

#define AnimationDelay 0.3
@interface PageContentViewController ()<UIPageViewControllerDelegate,UIPageViewControllerDataSource,UIGestureRecognizerDelegate,LSYMenuViewDelegate,LSYCatalogViewControllerDelegate,TextViewControllerDelegate>
{
    NSUInteger _chapter;    //当前显示的章节
    NSUInteger _page;       //当前显示的页数
    NSUInteger _chapterChange;  //将要变化的章节
    NSUInteger _pageChange;     //将要变化的页数
    BOOL _isTransition;     //是否开始翻页
}
@property (nonatomic ,strong) UIPageViewController *pageViewController;
@property (nonatomic,strong) TextViewController *readView;   //当前阅读视图
@property (nonatomic,getter=isShowBar) BOOL showBar; //是否显示状态栏
@property (nonatomic,strong) LSYMenuView *menuView; //菜单栏
@property (nonatomic,strong) LSYCatalogViewController *catalogVC;   //侧边栏
@property (nonatomic,strong) UIView * catalogView;  //侧边栏背景

@end

@implementation PageContentViewController

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    
    if (self.dissCallback) {
        self.dissCallback();
    }
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor orangeColor];
    
    [self addChildViewController:self.pageViewController];
    [self.view addSubview:_pageViewController.view];
    _chapter = _model.record.chapter;
    _page = _model.record.page;
    [_pageViewController setViewControllers:@[[self readViewWithChapter:_chapter page:_page]] direction:UIPageViewControllerNavigationDirectionForward animated:YES completion:nil];
    [self.view addGestureRecognizer:({
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showToolMenu)];
        tap.delegate = self;
        tap;
    })];
    [self.view addSubview:self.menuView];
    
    [self addChildViewController:self.catalogVC];
    [self.view addSubview:self.catalogView];
    [self.catalogView addSubview:self.catalogVC.view];
    //添加笔记
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addNotes:) name:LSYNoteNotification object:nil];
    //通过通知来做的
    
    //LSYTextThemeNotification
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeTextColorNotie:) name:LSYTextThemeNotification object:nil];

    
    
}

#pragma mark -- 文字的颜色发生变化

- (void)changeTextColorNotie:(NSNotification *)noti {
    
    
    UIColor *color = noti.object;
    NSLog(@"noti=====>>%@", noti.object);
    //    [DWReadonfig shareInstance].fontColor = color;
    
    
    [_model.record.chapterModel updateTextColor:color];
    
    
    [_pageViewController setViewControllers:@[[self readViewWithChapter:_model.record.chapter page:(_model.record.page>_model.record.chapterModel.pageCount-1)?_model.record.chapterModel.pageCount-1:_model.record.page]] direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];

    
    
}

#pragma mark -- 添加笔记


-(void)addNotes:(NSNotification *)no
{
    BookNote *model = no.object;
    BookChapter *chapter = [DWReadManager shareInstance].bookModel.chapters[_chapter];
    
    NSMutableArray *notes = [[NSMutableArray alloc]init];
    if (chapter.notes) {
        [notes addObjectsFromArray:chapter.notes];
    }
    [notes addObject:model];
    chapter.notes = notes;
    model.recordModel = [_model.record copy];
    [[_model mutableArrayValueForKey:@"notes"] addObject:model];    //这样写才能KVO数组变化
    [DWReadManager shareInstance].bookModel = _model;
    [DWReadOPeration showAlertTitle:@"" content:@"保存笔记成功"];
    
    
//    [_model.record.chapterModel];
    
//    [_model.record.chapterModel updateFont];
    
    [_model.record.chapterModel updateNoteWithContent:_readView.showAtrContent page:_page note:model];

    
    [_pageViewController setViewControllers:@[[self readViewWithChapter:_model.record.chapter page:(_model.record.page>_model.record.chapterModel.pageCount-1)?_model.record.chapterModel.pageCount-1:_model.record.page]] direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
//    [self updateReadModelWithChapter:_model.record.chapter page:(_model.record.page>_model.record.chapterModel.pageCount-1)?_model.record.chapterModel.pageCount-1:_model.record.page];
    
}

-(BOOL)prefersStatusBarHidden
{
    return !_showBar;
}
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
-(void)showToolMenu
{
//    [_readView.readView cancelSelected];
    NSString * key = [NSString stringWithFormat:@"%d_%d",(int)_model.record.chapter,(int)_model.record.page];
    
    id state = _model.marksRecord[key];
    state?(_menuView.topView.state=1): (_menuView.topView.state=0);
    [self.menuView showAnimation:YES];
    
}
-(LSYCatalogViewController *)catalogVC
{
    if (!_catalogVC) {
        _catalogVC = [[LSYCatalogViewController alloc] init];
        _catalogVC.readModel = _model;
        _catalogVC.catalogDelegate = self;
    }
    return _catalogVC;
}
-(UIView *)catalogView
{
    if (!_catalogView) {
        _catalogView = [[UIView alloc] initWithFrame:CGRectMake(-ViewSize(self.view).width, 0, 2*ViewSize(self.view).width, ViewSize(self.view).height)];
        _catalogView.backgroundColor = [UIColor clearColor];
        _catalogView.hidden = YES;
        [_catalogView addGestureRecognizer:({
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hiddenCatalog)];
            tap.delegate = self;
            tap;
        })];
    }
    return _catalogView;
}
#pragma mark - init
-(LSYMenuView *)menuView
{
    if (!_menuView) {
        _menuView = [[LSYMenuView alloc] initWithFrame:self.view.frame];
        _menuView.hidden = YES;
        _menuView.delegate = self;
        _menuView.recordModel = _model.record;
    }
    return _menuView;
}
#pragma mark - CatalogViewController Delegate
-(void)catalog:(LSYCatalogViewController *)catalog didSelectChapter:(NSUInteger)chapter page:(NSUInteger)page
{
     [_pageViewController setViewControllers:@[[self readViewWithChapter:chapter page:page]] direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
    [self updateReadModelWithChapter:chapter page:page];
    [self hiddenCatalog];
    
}
#pragma mark -  UIGestureRecognizer Delegate
//解决TabView与Tap手势冲突
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([NSStringFromClass([touch.view class]) isEqualToString:@"UITableViewCellContentView"]) {
        return NO;
    }
    return  YES;
}
#pragma mark - Privite Method
-(void)catalogShowState:(BOOL)show
{
    show?({
        _catalogView.hidden = !show;
        [UIView animateWithDuration:AnimationDelay animations:^{
            self.catalogView.frame = CGRectMake(0, 0,2*ViewSize(self.view).width, ViewSize(self.view).height);
            
        } completion:^(BOOL finished) {
            [self.catalogView insertSubview:[[UIImageView alloc] initWithImage:[self blurredSnapshot]] atIndex:0];
        }];
    }):({
        if ([self.catalogView.subviews.firstObject isKindOfClass:[UIImageView class]]) {
            [_catalogView.subviews.firstObject removeFromSuperview];
        }
        [UIView animateWithDuration:AnimationDelay animations:^{
            self.catalogView.frame = CGRectMake(-ViewSize(self.view).width, 0, 2*ViewSize(self.view).width, ViewSize(self.view).height);
        } completion:^(BOOL finished) {
            self.catalogView.hidden = !show;
            
        }];
    });
}
-(void)hiddenCatalog
{
    [self catalogShowState:NO];
}

-(UIImage *)blurredSnapshot {
    
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame)), NO, 1.0f);
    [self.view drawViewHierarchyInRect:CGRectMake(0, 0, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame)) afterScreenUpdates:NO];
    UIImage *snapshotImage = UIGraphicsGetImageFromCurrentImageContext();
    UIImage *blurredSnapshotImage = [snapshotImage applyLightEffect];
    UIGraphicsEndImageContext();
    return blurredSnapshotImage;
}
#pragma mark - Menu View Delegate
-(void)menuViewDidHidden:(LSYMenuView *)menu
{
     _showBar = NO;
    [self setNeedsStatusBarAppearanceUpdate];
}
-(void)menuViewDidAppear:(LSYMenuView *)menu
{
    _showBar = YES;
    [self setNeedsStatusBarAppearanceUpdate];
    
}
-(void)menuViewInvokeCatalog:(LSYBottomMenuView *)bottomMenu
{
    [_menuView hiddenAnimation:NO];
    [self catalogShowState:YES];
    
}

-(void)menuViewJumpChapter:(NSUInteger)chapter page:(NSUInteger)page
{
    [_pageViewController setViewControllers:@[[self readViewWithChapter:chapter page:page]] direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
    [self updateReadModelWithChapter:chapter page:page];
}
-(void)menuViewFontSize:(LSYBottomMenuView *)bottomMenu
{

    [_model.record.chapterModel updateFont];
    [_pageViewController setViewControllers:@[[self readViewWithChapter:_model.record.chapter page:(_model.record.page>_model.record.chapterModel.pageCount-1)?_model.record.chapterModel.pageCount-1:_model.record.page]] direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
    [self updateReadModelWithChapter:_model.record.chapter page:(_model.record.page>_model.record.chapterModel.pageCount-1)?_model.record.chapterModel.pageCount-1:_model.record.page];
}

-(void)menuViewMark:(LSYTopMenuView *)topMenu
{


    NSString * key = [NSString stringWithFormat:@"%d_%d",(int)_model.record.chapter,(int)_model.record.page];
    id state = _model.marksRecord[key];
    if (state) {
//如果存在移除书签信息
        [_model.marksRecord removeObjectForKey:key];
        [[_model mutableArrayValueForKey:@"marks"] removeObject:state];
    }
    else{
//记录书签信息
        BookMark *model = [[BookMark alloc] init];
        model.date = [NSDate date];
        model.recordModel = [_model.record copy];
        [[_model mutableArrayValueForKey:@"marks"] addObject:model];
        [_model.marksRecord setObject:model forKey:key];
    }
    _menuView.topView.state = !state;


}
-(void)updateReadModelWithChapter:(NSUInteger)chapter page:(NSUInteger)page
{
    _chapter = chapter;
    _page = page;
    _model.record.chapterModel = _model.chapters[chapter];
    _model.record.chapter = chapter;
    _model.record.page = page;
    [DWReadManager shareInstance].bookModel = _model;
    [ReadBook updateLocalModel:_model url:_resourceURL];
    
}

#pragma mark - Read View Controller Delegate
-(void)readViewEndEdit:(TextViewController *)readView
{
    for (UIGestureRecognizer *ges in self.pageViewController.view.gestureRecognizers) {
        if ([ges isKindOfClass:[UIPanGestureRecognizer class]]) {
            ges.enabled = YES;
            break;
        }
    }
}
-(void)readViewEditeding:(TextViewController *)readView
{
    for (UIGestureRecognizer *ges in self.pageViewController.view.gestureRecognizers) {
        if ([ges isKindOfClass:[UIPanGestureRecognizer class]]) {
            ges.enabled = NO;
            break;
        }
    }
}
#pragma mark -PageViewController DataSource
- (nullable UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController
{
    
    _pageChange = _page;
    _chapterChange = _chapter;
    //返回即将显示的控制器
    if (_pageChange==0&&_chapterChange==0) {
        [self dismissViewControllerAnimated:YES completion:nil];
        return nil;
    }
    if (_pageChange>0) {
        _pageChange--;
    }else{
        if (_chapterChange>=0) {
            _chapterChange--;
            BookChapter *chapter = _model.chapters[_chapterChange];
            _pageChange = chapter.pageCount-1;
        }
        
    }
    if (_chapterChange<0) {
        return nil;
    }
       return [self readViewWithChapter:_chapterChange page:_pageChange];
    
}

- (nullable UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController
{
    
    
    //返回即将显示的控制器
    _pageChange = _page;
    _chapterChange = _chapter;
    BookChapter *chapter = _model.chapters[_chapterChange];
    if (_chapterChange==_model.chapters.count-1&&_pageChange==chapter.pageCount) {
        
        return nil;
    }
    if (_pageChange<chapter.pageCount-1) {
        _pageChange++;
    }else{
        _pageChange=0;
        _chapterChange++;
    }
    if (_chapterChange>=_model.chapters.count) {
        return nil;
    }
       return [self readViewWithChapter:_chapterChange page:_pageChange];

}
#pragma mark -PageViewController Delegate
- (void)pageViewController:(UIPageViewController *)pageViewController didFinishAnimating:(BOOL)finished previousViewControllers:(NSArray *)previousViewControllers transitionCompleted:(BOOL)completed
{
    if (!completed) {
            TextViewController *readView = previousViewControllers.firstObject;
    //        _readView = readView;
            _page = readView.recordModel.page;
            _chapter = readView.recordModel.chapter;
        }
        else{
            [self updateReadModelWithChapter:_chapter page:_page];
        }
}
- (void)pageViewController:(UIPageViewController *)pageViewController willTransitionToViewControllers:(NSArray<UIViewController *> *)pendingViewControllers
{
    _chapter = _chapterChange;
    _page = _pageChange;
}

#pragma mark - Create Read View Controller

-(TextViewController *)readViewWithChapter:(NSUInteger)chapter page:(NSUInteger)page{

    // 怎么给他做分页的这个也是有点奇怪
    
    
    // 如果是当前发生变化的时候做解析
    
    // 字体大小发生变化
    // 字体颜色发生变化
    // 下滑线发生变化
    
    if (_model.record.chapter != chapter) {
        [_model.record.chapterModel updateFont];
        if (!_model.chapters[chapter].epubframeRef) {
            NSString *path = [kDocuments stringByAppendingPathComponent:_model.chapters[chapter].chapterpath];
            NSString* html = [[NSString alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL fileURLWithPath:path]] encoding:NSUTF8StringEncoding];
            _model.chapters[chapter].content = [html stringByConvertingHTMLToPlainText];
            [_model.chapters[chapter] parserEpubToDictionary];
        }
        [ _model.chapters[chapter] paginateEpubWithBounds:CGRectMake(0,0, [UIScreen mainScreen].bounds.size.width-LeftSpacing-RightSpacing, [UIScreen mainScreen].bounds.size.height-TopSpacing-BottomSpacing)];
    }
    TextViewController *read = [[TextViewController alloc] init];
//    _readView = read;
    read.recordModel = _model.record;
    
    // 判断 如果书没有数据
    if (!_model.chapters[chapter].epubframeRef) {
        NSString *path = [kDocuments stringByAppendingPathComponent:_model.chapters[chapter].chapterpath];
        NSString* html = [[NSString alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL fileURLWithPath:path]] encoding:NSUTF8StringEncoding];
        _model.chapters[chapter].content = [html stringByConvertingHTMLToPlainText];
        [_model.chapters[chapter] parserEpubToDictionary];
        [_model.chapters[chapter] paginateEpubWithBounds:CGRectMake(0,0, [UIScreen mainScreen].bounds.size.width-LeftSpacing-RightSpacing, [UIScreen mainScreen].bounds.size.height-TopSpacing-BottomSpacing)];
    }
    BookChapter *chapmodel = self.model.chapters[chapter];
    
  
    
    NSArray *array = chapmodel.epubframeRef;
    if (page > array.count - 1) {
          return nil;
      }
    id frameRef = array[page];
    read.epubFrameRef = frameRef;
    read.showContent = chapmodel.epubString[page];
    read.showAtrContent = chapmodel.epubArstr[page];
    read.imageArray = self.model.chapters[chapter].imageArray;
    read.content = self.model.chapters[chapter].content;
//    CTFrame ctf = read.epubFrameRef;
    read.page = page;
    read.chart = chapter;
    read.delegate = self;
    read.chapterModel = chapmodel;
    NSLog(@"_readGreate");
    _readView = read;
    
    return _readView;
}



-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];

    _pageViewController.view.frame = self.view.frame;
//    _catalogView.frame = CGRectMake(-ViewSize(self.view).width, 0, 2*ViewSize(self.view).width, ViewSize(self.view).height);
    _catalogVC.view.frame = CGRectMake(0, 0, ViewSize(self.view).width-100, ViewSize(self.view).height);
    [_catalogVC reload];
}

-(UIPageViewController *)pageViewController
{
    if (!_pageViewController) {
        _pageViewController = [[UIPageViewController alloc] initWithTransitionStyle:0 navigationOrientation:0 options:nil];
        _pageViewController.delegate = self;
        _pageViewController.dataSource = self;
        _pageViewController.doubleSided = NO;
        
    }
    return _pageViewController;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
