/**
 This is a "special" class which marks nodes types not supported by TouchXML.
 They could work... or not... becareful when you encounter them.
*/

#import "CXMLNode.h"

@interface CXMLUnsupportedNode : CXMLNode

@end
