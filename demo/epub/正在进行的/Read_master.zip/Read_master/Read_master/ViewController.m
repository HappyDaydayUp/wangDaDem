//
//  ViewController.m
//  Read_master
//
//  Created by 吴小闯 on 2020/4/18.
//  Copyright © 2020 吴小闯. All rights reserved.
//

#import "ViewController.h"
#import "PageContentViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(100, 200, 100, 100);
    [button setTitle:@"阅读" forState:UIControlStateNormal];
    [self.view addSubview:button];
    [button addTarget:self action:@selector(buttonAction) forControlEvents:UIControlEventTouchUpInside];
    
    
}

- (void)buttonAction{
    PageContentViewController *pageView = [[PageContentViewController alloc]init];
    
    CGFloat light = UIScreen.mainScreen.brightness;
    
    pageView.dissCallback = ^{
        UIScreen.mainScreen.brightness = light;
    };
    
    
    
//    NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"每天懂一点好玩心理学"withExtension:@"epub"];
    
//    NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"张学良传"withExtension:@"epub"];
    NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"iOS安全攻防"withExtension:@"epub"];

    //iOS 安全攻防
    pageView.resourceURL = fileURL;    //文件位
    ReadBook *model = [ReadBook getLocalModelWithURL:fileURL];
    pageView.model = model;
    [[DWReadManager shareInstance]setBookModel:model];
    pageView.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:pageView animated:YES completion:^{
        
    }];
}



@end
