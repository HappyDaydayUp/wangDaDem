//
//  TextViewController.h
//  Read_master
//
//  Created by 吴小闯 on 2020/4/18.
//  Copyright © 2020 吴小闯. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ReadView.h"
NS_ASSUME_NONNULL_BEGIN
@class TextViewController;
@protocol TextViewControllerDelegate <NSObject>
-(void)readViewEditeding:(TextViewController *)readView;
-(void)readViewEndEdit:(TextViewController *)readView;
@end
@interface TextViewController : UIViewController
@property (nonatomic ,assign) NSInteger chart;
@property (nonatomic ,assign) NSInteger page;
@property (nonatomic,strong) ReadView *readView;
@property (nonatomic,strong) NSString *content; //显示的内容
@property (nonatomic,strong) id epubFrameRef;  //epub显示内容
@property (nonatomic,strong) NSArray *imageArray;  //epub显示的图片
@property (nonatomic,strong) Book *recordModel;   //阅读进度

@property (nonatomic, copy) NSString *showContent; // 展示的内容

@property (nonatomic, copy) NSAttributedString *showAtrContent;

@property (nonatomic,weak) id<TextViewControllerDelegate>delegate;

@property (nonatomic, strong) BookChapter *chapterModel;



@end

NS_ASSUME_NONNULL_END
