//
//  Book.h
//  Read_master
//
//  Created by 吴小闯 on 2020/4/20.
//  Copyright © 2020 吴小闯. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BookChapter.h"
NS_ASSUME_NONNULL_BEGIN

@interface Book : NSObject<NSCopying,NSCoding>
@property (nonatomic,strong) BookChapter *chapterModel;  //阅读的章节
@property (nonatomic) NSUInteger page;  //阅读的页数
@property (nonatomic) NSUInteger chapter;    //阅读的章节数
@property (nonatomic) NSUInteger chapterCount;  //总章节数

@end

NS_ASSUME_NONNULL_END
