//
//  ReadBook.m
//  Read_master
//
//  Created by 吴小闯 on 2020/4/20.
//  Copyright © 2020 吴小闯. All rights reserved.
//

#import "ReadBook.h"

@implementation ReadBook

-(instancetype)initWithContent:(NSString *)content{
    self = [super init];
    if (self) {
        
    }
    return self;
}
-(instancetype)initWithePub:(NSString *)ePubPath;
{
    self = [super init];
    if (self) {
        _chapters = [DWReadOPeration ePubFileHandle:ePubPath];
        
        
        _notes = [NSMutableArray array];
        _marks = [NSMutableArray array];
        _record = [[Book alloc] init];
        _record.chapterModel = _chapters.firstObject;
        _record.chapterCount = _chapters.count;
        _marksRecord = [NSMutableDictionary dictionary];
        
        
      
        
        
    }
    return self;
}
-(void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:self.content forKey:@"content"];
    [aCoder encodeObject:self.marks forKey:@"marks"];
    [aCoder encodeObject:self.notes forKey:@"notes"];
    [aCoder encodeObject:self.chapters forKey:@"chapters"];
    [aCoder encodeObject:self.record forKey:@"record"];
    [aCoder encodeObject:self.resource forKey:@"resource"];
    [aCoder encodeObject:self.marksRecord forKey:@"marksRecord"];
    
}
-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [super init];
    if (self) {
        self.content = [aDecoder decodeObjectForKey:@"content"];
        self.marks = [aDecoder decodeObjectForKey:@"marks"];
        self.notes = [aDecoder decodeObjectForKey:@"notes"];
        self.chapters = [aDecoder decodeObjectForKey:@"chapters"];
        self.record = [aDecoder decodeObjectForKey:@"record"];
        self.resource = [aDecoder decodeObjectForKey:@"resource"];
        self.marksRecord = [aDecoder decodeObjectForKey:@"marksRecord"];
        
        [_chapters enumerateObjectsUsingBlock:^(BookChapter * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//            NSLog(@"enumerateObjectsUsingBlock==obj.content=====>>>%@", obj.content);
//            NSLog(@"enumerateObjectsUsingBlock==obj.title=====>>>%@", obj.title);
          //  NSLog(@"enumerateObjectsUsingBlock==obj.epubImagePath======>>>%@", obj.epubImagePath);

        }];
    }
    return self;
}
+(id)getLocalModelWithURL:(NSURL *)url{
    NSString *key = [url.path lastPathComponent];
    NSLog(@"url==url====>>%@", url);
    
    NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:key];
    if (!data) {
        if ([[key pathExtension] isEqualToString:@"epub"]){
            NSLog(@"this is epub");
            ReadBook *model = [[ReadBook alloc] initWithePub:url.path];
            model.resource = url;
            [ReadBook updateLocalModel:model url:url];
            return model;
        }
        else{
            @throw [NSException exceptionWithName:@"FileException" reason:@"文件格式错误" userInfo:nil];
        }

    }
    NSKeyedUnarchiver *unarchive = [[NSKeyedUnarchiver alloc]initForReadingWithData:data];
    //主线程操作
    ReadBook *model = [unarchive decodeObjectForKey:key];
    return model;
    
}

+(void)updateLocalModel:(ReadBook *)readModel url:(NSURL *)url
{
    
    NSString *key = [url.path lastPathComponent];
    NSMutableData *data=[[NSMutableData alloc]init];
    NSKeyedArchiver *archiver=[[NSKeyedArchiver alloc]initForWritingWithMutableData:data];
    [archiver encodeObject:readModel forKey:key];
    [archiver finishEncoding];
    [[NSUserDefaults standardUserDefaults] setObject:data forKey:key];
}
@end
