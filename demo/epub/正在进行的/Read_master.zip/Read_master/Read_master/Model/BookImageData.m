//
//  BookImageData.m
//  Read_master
//
//  Created by 网达 on 2020/5/8.
//  Copyright © 2020 吴小闯. All rights reserved.
//

#import "BookImageData.h"

@implementation BookImageData


- (instancetype)initWithCoder:(NSCoder *)coder {
    
    self = [super init];
    if (self) {
        self.imageRect = [coder decodeCGRectForKey:@"imageRect"];
        NSNumber *position = [coder decodeObjectForKey:@"position"];
        self.position = position.integerValue;
        self.url = [coder decodeObjectForKey:@"url"];
        
    }
    return self;
    
}

- (void)encodeWithCoder:(NSCoder *)coder
{
    [coder encodeObject:self.url forKey:@"url"];
    [coder encodeObject:@(self.position) forKey:@"position"];

    [coder encodeCGRect:self.imageRect forKey:@"imageRect"];
}


@end
