//
//  ReadBook.h
//  Read_master
//
//  Created by 吴小闯 on 2020/4/20.
//  Copyright © 2020 吴小闯. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Book.h"

NS_ASSUME_NONNULL_BEGIN

@interface ReadBook : NSObject<NSCoding>
@property (nonatomic,strong) NSURL *resource;//资源路径
@property (nonatomic,copy) NSString *content;//电子书文本内容
@property (nonatomic,strong) NSMutableArray <BookMark *>*marks;
@property (nonatomic,strong) NSMutableArray <BookNote *>*notes;
@property (nonatomic,strong) NSMutableArray <BookChapter *>*chapters;
@property (nonatomic,strong) NSMutableDictionary *marksRecord;
@property (nonatomic,strong) Book *record;

-(instancetype)initWithContent:(NSString *)content;
-(instancetype)initWithePub:(NSString *)ePubPath;
+(void)updateLocalModel:(ReadBook *)readModel url:(NSURL *)url;
+(id)getLocalModelWithURL:(NSURL *)url;
@end

NS_ASSUME_NONNULL_END
