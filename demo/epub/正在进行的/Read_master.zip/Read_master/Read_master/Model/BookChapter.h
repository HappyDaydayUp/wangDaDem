//
//  BookChapter.h
//  Read_master
//
//  Created by 吴小闯 on 2020/4/20.
//  Copyright © 2020 吴小闯. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreText/CoreText.h>
#import "BookImageData.h"

@class BookNote;
//@class BookImageData;
NS_ASSUME_NONNULL_BEGIN
typedef  NS_ENUM(NSInteger,ReaderType){
    ReaderTxt,
    ReaderEpub
};



@interface BookChapter : NSObject
@property (nonatomic,strong) NSString *content;
@property (nonatomic,strong) NSString *title;
@property (nonatomic) NSUInteger pageCount;
-(NSString *)stringOfPage:(NSUInteger)index;
-(void)updateFont;

/// 更新文字的颜色
/// @param textColor 文字的颜色
- (void)updateTextColor:(UIColor *)textColor;



/// 更新笔记
/// @param content 当前内容
/// @param page 位置
- (void)updateNoteWithContent:(NSAttributedString *)content page:(NSInteger)page note:(BookNote *)note;

@property (nonatomic,copy) NSString *chapterpath;
@property (nonatomic,copy) NSString *html;

@property (nonatomic,copy) NSArray *epubContent;

@property (nonatomic,copy) NSArray *epubString; // 展示的文字
@property (nonatomic, copy) NSArray<NSAttributedString *> *epubArstr;


@property (nonatomic,strong) NSArray *epubframeRef;
@property (nonatomic,copy) NSString *epubImagePath;
@property (nonatomic,copy) NSArray <BookImageData *> *imageArray;
@property (nonatomic, strong) NSDictionary<NSNumber *, BookImageData *> *imageDataDic;

@property (nonatomic,copy) NSArray *pageLocations;//每一页在章节中的位置
@property (nonatomic,assign) ReaderType type;
@property (nonatomic,strong) NSMutableArray <BookNote *>*notes;//该章节的笔记
+(id)chapterWithEpub:(NSString *)chapterpath title:(NSString *)title imagePath:(NSString *)path;
-(void)parserEpubToDictionary;
-(void)paginateEpubWithBounds:(CGRect)bounds;
@end



NS_ASSUME_NONNULL_END
