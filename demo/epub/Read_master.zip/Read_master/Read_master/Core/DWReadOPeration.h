//
//  DWReadOPeration.h
//  Read_master
//
//  Created by 吴小闯 on 2020/4/20.
//  Copyright © 2020 吴小闯. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DWReadOPeration : NSObject
+(void)separateChapter:(NSMutableArray **)chapters content:(NSString *)content;
+(NSString *)encodeWithURL:(NSURL *)url;
+(UIButton *)commonButtonSEL:(SEL)sel target:(id)target;
+(UIViewController *)getCurrentVC;
+(void)showAlertTitle:(NSString *)title content:(NSString *)string;
/**
 * ePub格式处理
 * 返回章节信息数组
 */
+(NSMutableArray *)ePubFileHandle:(NSString *)path;
//+(NSString *)ePubImageRelatePath:(NSString *)epubPath;  //epub图片的相对路径
@end

NS_ASSUME_NONNULL_END
