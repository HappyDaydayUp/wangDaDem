//
//  DWReadManager.h
//  Read_master
//
//  Created by 吴小闯 on 2020/4/20.
//  Copyright © 2020 吴小闯. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DWReadonfig.h"
NS_ASSUME_NONNULL_BEGIN

#define LoadReadBook [DWReadManager sharedManager]


@interface DWReadManager : NSObject
@property (nonatomic ,strong) ReadBook *bookModel;




/// 点击在当前页面的位置
@property (nonatomic, assign) NSRange tapPageRange;

+(instancetype)shareInstance;
+(CTFrameRef)parserContent:(NSString *)content config:(DWReadonfig *)parser bouds:(CGRect)bounds;
+(NSDictionary *)parserAttribute:(DWReadonfig *)config;
//根据触碰点获取当前文字的索引
+(CFIndex)parserIndexWithPoint:(CGPoint)point frameRef:(CTFrameRef)frameRef;
/**
 *  根据触碰点获取默认选中区域
 *  @range 选中范围
 *  @return 选中区域
 */
+(CGRect)parserRectWithPoint:(CGPoint)point range:(NSRange *)selectRange frameRef:(CTFrameRef)frameRef;
/**
 *  根据触碰点获取默认选中区域
 *  @range 选中范围
 *  @return 选中区域的集合
 */
+(NSArray *)parserRectsWithPoint:(CGPoint)point range:(NSRange *)selectRange frameRef:(CTFrameRef)frameRef paths:(NSArray *)paths;
/**
 *  根据触碰点获取默认选中区域
 *  @range 选中范围
 *  @return 选中区域的集合
 *  @direction 滑动方向 (0 -- 从左侧滑动 1-- 从右侧滑动)
 */
+(NSArray *)parserRectsWithPoint:(CGPoint)point range:(NSRange *)selectRange frameRef:(CTFrameRef)frameRef paths:(NSArray *)paths direction:(BOOL) direction;

/**
 转换epub文件成CTFrameRef对象

 @param content epub文件处理后的内容
 @param parser 字体属性
 @param bounds 渲染区间
 */
+(CTFrameRef)parserEpub:(NSArray *)content config:(DWReadonfig *)parser bounds:(CGRect)bounds;
+(NSAttributedString *)parserEpubAttribute:(NSArray *)content config:(DWReadonfig *)parser bounds:(CGRect)bounds;

/**
 解析图片属性

 */
+(NSAttributedString *)parserEpubImageWithSize:(NSDictionary *)dic config:(DWReadonfig *)config;
@end


NS_ASSUME_NONNULL_END
