//
//  ReadView.h
//  Read_master
//
//  Created by 吴小闯 on 2020/4/20.
//  Copyright © 2020 吴小闯. All rights reserved.
//

#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN
@protocol ReadViewDelegate <NSObject>

-(void)readViewEditeding;
-(void)readViewEndEdit;

@end
@interface ReadView : UIView
- (instancetype)initWithFrame:(CGRect)frame WithRefFrame:(CTFrameRef)frameRef;
@property (nonatomic,assign) NSInteger charpt;
@property (nonatomic,assign) NSInteger page;
@property (nonatomic,assign) CTFrameRef frameRef; // 这个是实际展示的文字
@property (nonatomic,copy) NSString *content;
@property (nonatomic,strong) NSArray *imageArray;
@property (nonatomic,strong) id<ReadViewDelegate>delegate;
@property (nonatomic, strong) BookChapter *chapterModel;

@end

NS_ASSUME_NONNULL_END
