//
//  TextViewController.m
//  Read_master
//
//  Created by 吴小闯 on 2020/4/18.
//  Copyright © 2020 吴小闯. All rights reserved.
//

#import "TextViewController.h"

@interface TextViewController ()<ReadViewDelegate>

@end

@implementation TextViewController

- (void)dealloc
{
    [NSNotificationCenter.defaultCenter removeObserver:self];
}



- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[DWReadonfig shareInstance].theme];
    [self.view addSubview:self.readView];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeTheme:) name:LSYThemeNotification object:nil];

    self.view.backgroundColor = DWReadonfig.shareInstance.theme;
    
    NSLog(@"=self.showContent==self.showContent====>>>%@", self.showAtrContent);
    
    NSLog(@"=self.showContent==self.showContent====>>>%@", self.showAtrContent.string);

    NSLog(@"self._epubFrameRef======>>>%@", self.epubFrameRef);
        
}






-(void)changeTheme:(NSNotification *)no
{
    [DWReadonfig shareInstance].theme = no.object;
    [self.view setBackgroundColor:[DWReadonfig shareInstance].theme];
}

-(ReadView *)readView
{
    if (!_readView) {
        _readView = [[ReadView alloc]initWithFrame:CGRectMake(LeftSpacing,TopSpacing, self.view.frame.size.width-LeftSpacing-RightSpacing, self.view.frame.size.height-TopSpacing-BottomSpacing) WithRefFrame:(__bridge CTFrameRef)_epubFrameRef];
//        DWReadonfig *config = [DWReadonfig shareInstance];
//        _readView.frameRef = (__bridge CTFrameRef)_epubFrameRef;
        _readView.imageArray = _imageArray;
        _readView.content = _content;
        _readView.page = self.page;
        _readView.charpt = self.chart;
        _readView.chapterModel = self.chapterModel;
        _readView.delegate = self;
    }
    return _readView;
}

- (void)readViewUpdate {
    self.readView.frameRef = (__bridge CTFrameRef)_epubFrameRef;
    self.readView.imageArray = self.imageArray;
    self.readView.content = self.content;
    self.readView.page = self.page;
    self.readView.charpt = self.chart;
    
    
    
}


-(void)readViewEditeding
{
    if ([self.delegate respondsToSelector:@selector(readViewEditeding:)]) {
        [self.delegate readViewEditeding:self];
    }
}
-(void)readViewEndEdit
{
    if ([self.delegate respondsToSelector:@selector(readViewEndEdit:)]) {
        [self.delegate readViewEndEdit:self];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
