//
//  PageContentViewController.h
//  Read_master
//
//  Created by 吴小闯 on 2020/4/18.
//  Copyright © 2020 吴小闯. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^DissCallback)(void);

NS_ASSUME_NONNULL_BEGIN

@interface PageContentViewController : UIViewController
@property (nonatomic,strong) NSURL *resourceURL;
@property (nonatomic,strong) ReadBook *model;
@property (nonatomic, copy) DissCallback dissCallback;
@end

NS_ASSUME_NONNULL_END
