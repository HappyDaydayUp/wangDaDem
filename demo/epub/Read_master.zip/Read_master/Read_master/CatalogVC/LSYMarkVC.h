//
//  LSYMarkVC.h
//  LSYReader
//
//  Created by okwei on 16/6/2.
//  Copyright © 2016年 okwei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ReadBook.h"
@protocol LSYCatalogViewControllerDelegate;
@interface LSYMarkVC : UIViewController
@property (nonatomic,strong) ReadBook *readModel;
@property (nonatomic,weak) id<LSYCatalogViewControllerDelegate>delegate;
@end
