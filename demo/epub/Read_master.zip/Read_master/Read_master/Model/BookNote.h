//
//  BookNote.h
//  Read_master
//
//  Created by 吴小闯 on 2020/4/20.
//  Copyright © 2020 吴小闯. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Book.h"
NS_ASSUME_NONNULL_BEGIN

@interface BookNote : NSObject<NSCoding>
@property (nonatomic,strong) NSDate *date;
@property (nonatomic,copy) NSString *note;
@property (nonatomic,copy) NSString *content;
@property (nonatomic,assign) NSInteger chapter;//笔记所在的章节
@property (nonatomic,assign) NSInteger page;
@property (nonatomic,assign) NSInteger locationInChapterContent;//笔记在章节中所在的位置


/// 在页面的位置
@property (nonatomic, assign) NSInteger tappageLocation;

@property (nonatomic,strong) Book *recordModel;
@end

NS_ASSUME_NONNULL_END
