//
//  BookNote.m
//  Read_master
//
//  Created by 吴小闯 on 2020/4/20.
//  Copyright © 2020 吴小闯. All rights reserved.
//

#import "BookNote.h"

@implementation BookNote
-(void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:self.date forKey:@"date"];
    [aCoder encodeObject:self.note forKey:@"note"];
    [aCoder encodeObject:self.content forKey:@"content"];
    [aCoder encodeObject:self.recordModel forKey:@"recordModel"];
    [aCoder encodeInt64:self.chapter forKey:@"chapter"];
    [aCoder encodeInt64:self.chapter forKey:@"page"];
    [aCoder encodeInt64:self.locationInChapterContent forKey:@"locationInChapterContent"];
}

-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [super init];
    if (self) {
        self.date = [aDecoder decodeObjectForKey:@"date"];
        self.note = [aDecoder decodeObjectForKey:@"note"];
        self.content = [aDecoder decodeObjectForKey:@"content"];
        self.recordModel = [aDecoder decodeObjectForKey:@"recordModel"];
        self.chapter = [aDecoder decodeIntForKey:@"chapter"];
        self.page = [aDecoder decodeIntForKey:@"page"];
        self.locationInChapterContent = [aDecoder decodeIntForKey:@"locationInChapterContent"];
    }
    return self;
}
@end
