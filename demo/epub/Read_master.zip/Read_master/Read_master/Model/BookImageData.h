//
//  BookImageData.h
//  Read_master
//
//  Created by 网达 on 2020/5/8.
//  Copyright © 2020 吴小闯. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BookImageData<NSCoding> : NSObject

@property (nonatomic,strong) NSString *url; //图片链接
@property (nonatomic,assign) CGRect imageRect;  //图片位置
@property (nonatomic,assign) NSInteger position;

@end

NS_ASSUME_NONNULL_END
