//
//  BookChapter.m
//  Read_master
//
//  Created by 吴小闯 on 2020/4/20.
//  Copyright © 2020 吴小闯. All rights reserved.
//

#import "BookChapter.h"
#import "NSString+HTML.h"

@interface BookChapter ()
@property (nonatomic,strong) NSMutableArray *pageArray;
@end
@implementation BookChapter
- (instancetype)init
{
    self = [super init];
    if (self) {
        _pageArray = [NSMutableArray array];
        
    }
    return self;
}


// 数据解析的部分
+(id)chapterWithEpub:(NSString *)chapterpath title:(NSString *)title imagePath:(NSString *)path
{
    
    
    
    BookChapter *model = [[BookChapter alloc] init];

    model.title = title;
    model.epubImagePath = path;
    model.type = ReaderEpub;
    model.chapterpath = chapterpath;
    NSString * fullPath= [kDocuments stringByAppendingPathComponent:chapterpath];
    NSString* html = [[NSString alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL fileURLWithPath:fullPath]] encoding:NSUTF8StringEncoding];
    model.html = html;
    
    model.content = [html stringByConvertingHTMLToPlainText];
    [model parserEpubToDictionary];
    
    // 从这个地方开始 把它替换成Text Kit
    
    [model paginateEpubWithBounds:CGRectMake(0,0, [UIScreen mainScreen].bounds.size.width-LeftSpacing-RightSpacing, [UIScreen mainScreen].bounds.size.height-TopSpacing-BottomSpacing)];
    
    return model;
}
-(void)parserEpubToDictionary
{
    NSMutableArray *array = [NSMutableArray array];
    NSMutableArray *imageArray = [NSMutableArray array];
    NSScanner *scanner = [NSScanner scannerWithString:self.content];
    NSMutableString *newString = [[NSMutableString alloc] init];
    
    NSMutableDictionary<NSNumber *, BookImageData *> *imagDics = [NSMutableDictionary dictionary];
    while (![scanner isAtEnd]) {
        if ([scanner scanString:@"<img>" intoString:NULL]) {
            NSString *img;
            [scanner scanUpToString:@"</img>" intoString:&img];
            NSString *imageString = [[kDocuments stringByAppendingPathComponent:self.epubImagePath] stringByAppendingPathComponent:img];
            UIImage *image = [UIImage imageWithContentsOfFile:imageString];

            CGFloat width = ScreenSize.width - LeftSpacing - RightSpacing;
            CGFloat height = ScreenSize.height - TopSpacing - BottomSpacing;
            CGFloat scale = image.size.width / width;
            CGFloat realHeight = image.size.height / scale;
            CGSize size = CGSizeMake(width, realHeight);

            if (size.height > (height - 20)) {
                size.height = height - 20;
            }
            [array addObject:@{@"type":@"img",@"content":imageString?imageString:@"",@"width":@(size.width),@"height":@(size.height)}];
            //存储图片信息
            BookImageData *imageData = [[BookImageData alloc] init];
            imageData.url = imageString?imageString:@"";
            if (imageArray.count) {
                imageData.position = newString.length + imageArray.count;
            } else {
                imageData.position = newString.length;
            }
//            imageData.imageRect = CGRectMake(0, 0, size.width, size.height);
            NSLog(@"=imageData.position===imageData.position=====>>>>%@", @(imageData.position));
            
            imagDics[@(imageData.position)] = imageData;
            [imageArray addObject:imageData];

//            [newString appendString:@" "];
            [scanner scanString:@"</img>" intoString:NULL];
        }
        else{
            NSString *content;
            if ([scanner scanUpToString:@"<img>" intoString:&content]) {
                [array addObject:@{@"type":@"txt",@"content":content?content:@""}];
                [newString appendString:content?content:@""];
            }
        }
    }
    self.epubContent = [array copy];
    self.imageArray = [imageArray copy];
    self.imageDataDic = imagDics.copy;
//    self.content = [newString copy];
}
-(void)setContent:(NSString *)content
{
    _content = content;
    if (_type == ReaderTxt) {
         [self paginateWithBounds:CGRectMake(LeftSpacing, TopSpacing, [UIScreen mainScreen].bounds.size.width-LeftSpacing-RightSpacing, [UIScreen mainScreen].bounds.size.height-TopSpacing-BottomSpacing)];
    }
    
}
-(void)paginateWithBounds:(CGRect)bounds
{
    [_pageArray removeAllObjects];
    NSAttributedString *attrString;
    CTFramesetterRef frameSetter;
    CGPathRef path;
    NSMutableAttributedString *attrStr;
    attrStr = [[NSMutableAttributedString  alloc] initWithString:self.content];
    NSDictionary *attribute = [DWReadManager parserAttribute:[DWReadonfig shareInstance]];
    [attrStr setAttributes:attribute range:NSMakeRange(0, attrStr.length)];
    attrString = [attrStr copy];
    frameSetter = CTFramesetterCreateWithAttributedString((__bridge CFAttributedStringRef) attrString);
    path = CGPathCreateWithRect(bounds, NULL);
    int currentOffset = 0;
    int currentInnerOffset = 0;
    BOOL hasMorePages = YES;
    // 防止死循环，如果在同一个位置获取CTFrame超过2次，则跳出循环
    int preventDeadLoopSign = currentOffset;
    int samePlaceRepeatCount = 0;
    
    while (hasMorePages) {
        if (preventDeadLoopSign == currentOffset) {
            
            ++samePlaceRepeatCount;
            
        } else {
            
            samePlaceRepeatCount = 0;
        }
        
        if (samePlaceRepeatCount > 1) {
            // 退出循环前检查一下最后一页是否已经加上
            if (_pageArray.count == 0) {
                [_pageArray addObject:@(currentOffset)];
            }
            else {
                
                NSUInteger lastOffset = [[_pageArray lastObject] integerValue];
                
                if (lastOffset != currentOffset) {
                    [_pageArray addObject:@(currentOffset)];
                }
            }
            break;
        }
        
        [_pageArray addObject:@(currentOffset)];
        
        CTFrameRef frame = CTFramesetterCreateFrame(frameSetter, CFRangeMake(currentInnerOffset, 0), path, NULL);
        CFRange range = CTFrameGetVisibleStringRange(frame);
        if ((range.location + range.length) != attrString.length) {
            
            currentOffset += range.length;
            currentInnerOffset += range.length;
            
        } else {
            // 已经分完，提示跳出循环
            hasMorePages = NO;
        }
        if (frame) CFRelease(frame);
    }
    
    CGPathRelease(path);
    CFRelease(frameSetter);
    _pageCount = _pageArray.count;
}


#pragma mark -- 优化绘画的的

- (void)newPageEpubWithBounds:(CGRect)bound {
        
    
}


#pragma mark --- 这个地方是绘画的

-(void)paginateEpubWithBounds:(CGRect)bounds
{
    // 这个地方就是绘画的地方
    NSMutableAttributedString *attrString = [[NSMutableAttributedString alloc] init];
    for (NSDictionary *dic in _epubContent) {
      //  NSLog(@"==dic==dic=dic====>>>%@", dic);
        if ([dic[@"type"] isEqualToString:@"txt"]) {
            //解析文本
            
            NSLog(@"--%.2f",[DWReadonfig shareInstance].fontSize);
            NSDictionary *attr = [DWReadManager parserAttribute:[DWReadonfig shareInstance]];
            NSMutableAttributedString *subString = [[NSMutableAttributedString alloc] initWithString:dic[@"content"] attributes:attr];
            [attrString appendAttributedString:subString];
        }
        else if ([dic[@"type"] isEqualToString:@"img"]){
            //解析图片
            
            NSLog(@"==dic=dicdic=====>>>%@", dic);
            
            NSAttributedString *subString = [DWReadManager parserEpubImageWithSize:dic config:[DWReadonfig shareInstance]];
            
            NSLog(@"subString==subString==subString====>>>>%@", subString);
            NSLog(@"attrString.length=====attrString.length====>>>>%@", @(attrString.length));
            NSRange imageRange = NSMakeRange(attrString.length, subString.length);
            
            [attrString appendAttributedString:subString];

        }
    }
    
    attrString = [self addLineForNotes:attrString];
    
    // 绘画的地方
    CTFramesetterRef setterRef = CTFramesetterCreateWithAttributedString((__bridge CFAttributedStringRef)attrString);
    
    // 确定大小
    CGPathRef pathRef = CGPathCreateWithRect(bounds, NULL);
    CTFrameRef frameRef = CTFramesetterCreateFrame(setterRef, CFRangeMake(0, 0), pathRef, NULL);
    
    
    CFRange rang1 = CTFrameGetVisibleStringRange(frameRef);
    


    
    CFRange rang2 = CTFrameGetStringRange(frameRef);
    
    NSMutableArray *array = [NSMutableArray array];
    NSMutableArray *stringArr = [NSMutableArray array];
    NSMutableArray *locationArray = [NSMutableArray array];
    
    NSMutableArray<NSAttributedString *> *epubAtr = [NSMutableArray new];
    
    
    // 这个地方可能是图片的地方
    if (rang1.length+rang1.location == rang2.location+rang2.length) {
        CTFrameRef subFrameRef = CTFramesetterCreateFrame(setterRef, CFRangeMake(rang1.location,0), pathRef, NULL);
        
        NSLog(@"subFrameRef==subFrameRef====>>>%@", subFrameRef);
        
        CFRange range = CTFrameGetVisibleStringRange(subFrameRef);
        
        rang1 = CFRangeMake(range.location+range.length, 0);
        
        [array addObject:(__bridge id)subFrameRef];
        
        [stringArr addObject:[[attrString string] substringWithRange:NSMakeRange(range.location, range.length)]];
        [epubAtr addObject:[attrString attributedSubstringFromRange:NSMakeRange(range.location, range.length)]];
        
        [locationArray addObject:@(range.location)];
        
        
        
        CFRelease(subFrameRef);
    }
    else{
        // 这个正常的文字的情况
        
        while (rang1.length+rang1.location<rang2.location+rang2.length) {
            CTFrameRef subFrameRef = CTFramesetterCreateFrame(setterRef, CFRangeMake(rang1.location,0), pathRef, NULL);
            NSLog(@"");
            CFRange range = CTFrameGetVisibleStringRange(subFrameRef);
            rang1 = CFRangeMake(range.location+range.length, 0);
            
            [array addObject:(__bridge id)subFrameRef];
                        
            
            [stringArr addObject:[[attrString string] substringWithRange:NSMakeRange(range.location, range.length)]];
            
            [epubAtr addObject:[attrString attributedSubstringFromRange:NSMakeRange(range.location, range.length)]];
            [locationArray addObject:@(range.location)];
            
            CFRelease(subFrameRef);
            
        }
    }
    
    
    CFRelease(frameRef);

    CFRelease(setterRef);
    CFRelease(pathRef);
    _pageLocations = [locationArray copy];
    _epubframeRef = [array copy];
    _epubString = [stringArr copy];
    self.epubArstr = epubAtr.copy;
    
   
    
    _pageCount = _epubframeRef.count;
    
    NSLog(@"_epubframeRef.count=====>>>%@", @(_epubframeRef.count));
    NSLog(@"_epubframeRef.count=====>>>%@", @(_epubString.count));
    
    _content = attrString.string;
    for (BookNote *noteModel in _notes) {
        __block BOOL find = NO;
        [self.pageLocations enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if (noteModel.locationInChapterContent<[obj integerValue]&&idx>0) {
                noteModel.recordModel.page = idx-1;
                *stop = YES;
                find = YES;
            }
        }];
        if (!find) {
            noteModel.recordModel.page = self.pageArray.count-1;
        }
        ReadBook *readModel = [DWReadManager shareInstance].bookModel;
        [readModel.notes enumerateObjectsUsingBlock:^(BookNote * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if (obj.recordModel.chapter==noteModel.recordModel.chapter&&[obj.content isEqualToString:obj.content]) {
                obj = noteModel;
            }
        }];
    }
}
//TODO:add underline for notes 为笔记添加下划虚线
- (NSMutableAttributedString *)addLineForNotes:(NSMutableAttributedString *)chapterAttributeContent{
    
    NSMutableAttributedString * mAttribute = [[NSMutableAttributedString alloc] initWithAttributedString:chapterAttributeContent];
    for (BookNote *noteModel in _notes) {
        NSRange range = NSMakeRange(noteModel.locationInChapterContent, noteModel.content.length);
        NSMutableDictionary *attibutes = [NSMutableDictionary dictionary];
        //虚线
        //[attibutes setObject:@(NSUnderlinePatternDot|NSUnderlineStyleSingle) forKey:NSUnderlineStyleAttributeName];
        [attibutes setObject:@(NSUnderlinePatternSolid|NSUnderlineStyleSingle) forKey:NSUnderlineStyleAttributeName];
        [attibutes setObject:[UIColor redColor] forKey:NSUnderlineColorAttributeName];
        
        NSLog(@"===range.length===location>>>%@", @(range.length));
        NSLog(@"===range.length===location>>>%@", @(range.location));

        //===range.length===location>>>2
        //===range.length===location>>>18446744073709551614
        
        [mAttribute addAttributes:attibutes range:range];
        
    }
    
    return mAttribute;
}


#pragma mark -- 更新文字

-(void)updateFont
{
     [self paginateEpubWithBounds:CGRectMake(0,0, [UIScreen mainScreen].bounds.size.width-LeftSpacing-RightSpacing, [UIScreen mainScreen].bounds.size.height-TopSpacing-BottomSpacing)];
    
}

#pragma make -- 更新笔记

- (void)updateNoteWithContent:(NSAttributedString *)content page:(NSInteger)page note:(BookNote *)note {
    
    
  //  [self paginateEpubWithBounds:CGRectMake(0,0, [UIScreen mainScreen].bounds.size.width-LeftSpacing-RightSpacing, [UIScreen mainScreen].bounds.size.height-TopSpacing-BottomSpacing)];


    NSLog(@"=content==content=content==content===>>>%@", content);
    
    
    
    // 检测到如果他是图片就不能加下滑下
    
    
#if 1
    
    
    CGRect bounds = CGRectMake(0,0, [UIScreen mainScreen].bounds.size.width-LeftSpacing-RightSpacing, [UIScreen mainScreen].bounds.size.height-TopSpacing-BottomSpacing);
    if (content) {
                
        if (content.length) {
            
            
            NSMutableAttributedString * mAttribute = [[NSMutableAttributedString alloc] initWithAttributedString:content.copy];
            
            NSRange range = NSMakeRange(note.tappageLocation, note.content.length);
            NSMutableDictionary *attibutes = [NSMutableDictionary dictionary];
            [attibutes setObject:@(NSUnderlinePatternSolid|NSUnderlineStyleSingle) forKey:NSUnderlineStyleAttributeName];
            [attibutes setObject:[UIColor redColor] forKey:NSUnderlineColorAttributeName];
            
            //
            
            // 位置的问题
            
            [mAttribute addAttributes:attibutes range:range];
            
            NSMutableArray *epubArstr = self.epubArstr.mutableCopy;
            epubArstr[page] = mAttribute;
            self.epubArstr = epubArstr.copy;
            
            // 如果有文字的地方
            CTFramesetterRef setterRef = CTFramesetterCreateWithAttributedString((__bridge CFAttributedStringRef)mAttribute);
            CGPathRef pathRef = CGPathCreateWithRect(bounds, NULL);
            CTFrameRef frameRef = CTFramesetterCreateFrame(setterRef, CFRangeMake(0, 0), pathRef, NULL);
            
            
            NSMutableArray *frameRefs = self.epubframeRef.mutableCopy;
            frameRefs[page] = (__bridge id _Nonnull)(frameRef);
            self.epubframeRef = frameRefs.copy;
            
            CFRelease(frameRef);
            CFRelease(setterRef);
            CFRelease(pathRef);
            
            // 找到它的位置
            
            for (BookNote *noteModel in _notes) {
                __block BOOL find = NO;
                [self.pageLocations enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    if (noteModel.locationInChapterContent<[obj integerValue]&&idx>0) {
                        noteModel.recordModel.page = idx-1;
                        *stop = YES;
                        find = YES;
                    }
                }];
                if (!find) {
                    noteModel.recordModel.page = self.pageArray.count-1;
                }
                ReadBook *readModel = [DWReadManager shareInstance].bookModel;
                [readModel.notes enumerateObjectsUsingBlock:^(BookNote * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    if (obj.recordModel.chapter==noteModel.recordModel.chapter&&[obj.content isEqualToString:obj.content]) {
                        obj = noteModel;
                    }
                }];
            }
            
        } else {
            
            // 这个时候是图片
            
        }

        

      //  [self addLineForNotes:content.mutableCopy];
    } else {
        
    }
    
#endif
    
    
    
    
}


- (void)updateTextColor:(UIColor *)textColor {
    
    // 这个地方是更新实际数据的地方
    
    CGRect bounds = CGRectMake(0,0, [UIScreen mainScreen].bounds.size.width-LeftSpacing-RightSpacing, [UIScreen mainScreen].bounds.size.height-TopSpacing-BottomSpacing);
    
    NSMutableAttributedString *attrString = [[NSMutableAttributedString alloc] init];
    for (NSDictionary *dic in _epubContent) {
        if ([dic[@"type"] isEqualToString:@"txt"]) {
            
            NSString *content = dic[@"content"];
            NSLog(@"changeTextColorNotie===content=====>>>>>%@", content);
            //解析文本
            DWReadonfig.shareInstance.fontColor = textColor;
            NSDictionary *attr = [DWReadManager parserAttribute:DWReadonfig.shareInstance];
            NSMutableAttributedString *subString = [[NSMutableAttributedString alloc] initWithString:dic[@"content"] attributes:attr];
            [attrString appendAttributedString:subString];
        }
        else if ([dic[@"type"] isEqualToString:@"img"]){
            //解析图片
            NSAttributedString *subString = [DWReadManager parserEpubImageWithSize:dic config:[DWReadonfig shareInstance]];
            
            
            [attrString appendAttributedString:subString];
            
            
            

        }
    }
    
    NSLog(@"==attrString=attrString=====>>>>%@", attrString);
    
    
    attrString = [self addLineForNotes:attrString];
    
    
    CTFramesetterRef setterRef = CTFramesetterCreateWithAttributedString((__bridge CFAttributedStringRef)attrString);
    CGPathRef pathRef = CGPathCreateWithRect(bounds, NULL);
    CTFrameRef frameRef = CTFramesetterCreateFrame(setterRef, CFRangeMake(0, 0), pathRef, NULL);
    CFRange rang1 = CTFrameGetVisibleStringRange(frameRef);
    CFRange rang2 = CTFrameGetStringRange(frameRef);
    
    
    
    
    
    NSMutableArray *array = [NSMutableArray array];
    NSMutableArray *stringArr = [NSMutableArray array];
    NSMutableArray *locationArray = [NSMutableArray array];
    
    // 这个地方
    
    if (rang1.length+rang1.location == rang2.location+rang2.length) {
        CTFrameRef subFrameRef = CTFramesetterCreateFrame(setterRef, CFRangeMake(rang1.location,0), pathRef, NULL);
        CFRange range = CTFrameGetVisibleStringRange(subFrameRef);
        rang1 = CFRangeMake(range.location+range.length, 0);
        [array addObject:(__bridge id)subFrameRef];
        [stringArr addObject:[[attrString string] substringWithRange:NSMakeRange(range.location, range.length)]];
        [locationArray addObject:@(range.location)];
        CFRelease(subFrameRef);
    }
    else{
        while (rang1.length+rang1.location<rang2.location+rang2.length) {
            CTFrameRef subFrameRef = CTFramesetterCreateFrame(setterRef, CFRangeMake(rang1.location,0), pathRef, NULL);
            CFRange range = CTFrameGetVisibleStringRange(subFrameRef);
            rang1 = CFRangeMake(range.location+range.length, 0);
            [array addObject:(__bridge id)subFrameRef];
            [stringArr addObject:[[attrString string] substringWithRange:NSMakeRange(range.location, range.length)]];
            [locationArray addObject:@(range.location)];
            
            CFRelease(subFrameRef);
            
        }
    }
    
    CFRelease(setterRef);
    CFRelease(pathRef);
    _pageLocations = [locationArray copy];
    _epubframeRef = [array copy];
    _epubString = [stringArr copy];
    _pageCount = _epubframeRef.count;
    _content = attrString.string;
    for (BookNote *noteModel in _notes) {
        __block BOOL find = NO;
        [self.pageLocations enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if (noteModel.locationInChapterContent<[obj integerValue]&&idx>0) {
                noteModel.recordModel.page = idx-1;
                *stop = YES;
                find = YES;
            }
        }];
        if (!find) {
            noteModel.recordModel.page = self.pageArray.count-1;
        }
        ReadBook *readModel = [DWReadManager shareInstance].bookModel;
        [readModel.notes enumerateObjectsUsingBlock:^(BookNote * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if (obj.recordModel.chapter==noteModel.recordModel.chapter&&[obj.content isEqualToString:obj.content]) {
                obj = noteModel;
            }
        }];
    }
    
}



-(NSString *)stringOfPage:(NSUInteger)index
{
    NSUInteger local = [_pageArray[index] integerValue];
    NSUInteger length;
    if (index<self.pageCount-1) {
        length=  [_pageArray[index+1] integerValue] - [_pageArray[index] integerValue];
    }
    else{
        length = _content.length - [_pageArray[index] integerValue];
    }
    return [_content substringWithRange:NSMakeRange(local, length)];
}
-(id)copyWithZone:(NSZone *)zone
{
    BookChapter *model = [[BookChapter allocWithZone:zone] init];
    model.content = self.content;
    model.title = self.title;
    model.pageCount = self.pageCount;
    model.pageArray = self.pageArray;
    model.epubImagePath = self.epubImagePath;
    model.type = self.type;
    model.epubString = self.epubString;
    return model;
    
}
-(void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:self.content forKey:@"content"];
    [aCoder encodeObject:self.title forKey:@"title"];
    [aCoder encodeInteger:self.pageCount forKey:@"pageCount"];
    [aCoder encodeObject:self.pageArray forKey:@"pageArray"];
    [aCoder encodeObject:self.epubImagePath forKey:@"epubImagePath"];
    [aCoder encodeObject:@(self.type) forKey:@"type"];
    [aCoder encodeObject:self.epubContent forKey:@"epubContent"];
    [aCoder encodeObject:self.chapterpath forKey:@"chapterpath"];
    [aCoder encodeObject:self.html forKey:@"html"];
    [aCoder encodeObject:self.epubString forKey:@"epubString"];
//    [aCoder encodeObject:self.epubArstr forKey:@"epubArstr"];
    [aCoder encodeObject:self.notes forKey:@"notes"];
    [aCoder encodeObject:self.pageLocations forKey:@"pageLocations"];
    [aCoder encodeObject:self.imageDataDic forKey:@"imageDataDic"];
    [aCoder encodeObject:self.imageArray forKey:@"imageArray"];


    /**
     @property (nonatomic,copy) NSArray *epubframeRef;
     @property (nonatomic,copy) NSString *epubImagePath;
     @property (nonatomic,copy) NSArray <LSYImageData *> *imageArray;
    
     */
//    [aCoder encodeObject:self.epubframeRef forKey:@"epubframeRef"];
//    [aCoder encodeObject:self.epubImagePath forKey:@"epubImagePath"];
    
}
-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [super init];
    if (self) {
        _content = [aDecoder decodeObjectForKey:@"content"];
        self.title = [aDecoder decodeObjectForKey:@"title"];
        self.pageCount = [aDecoder decodeIntegerForKey:@"pageCount"];
        self.pageArray = [aDecoder decodeObjectForKey:@"pageArray"];
        self.type = [[aDecoder decodeObjectForKey:@"type"] integerValue];
        self.epubImagePath = [aDecoder decodeObjectForKey:@"epubImagePath"];
        self.epubContent = [aDecoder decodeObjectForKey:@"epubContent"];
        self.chapterpath = [aDecoder decodeObjectForKey:@"chapterpath"];
        self.html = [aDecoder decodeObjectForKey:@"html"];
        self.epubString = [aDecoder decodeObjectForKey:@"epubString"];
//        self.epubArstr = [aDecoder decodeObjectForKey:@"epubArstr"];
        self.notes = [aDecoder decodeObjectForKey:@"notes"];
        self.pageLocations = [aDecoder decodeObjectForKey:@"pageLocations"];
        self.imageDataDic = [aDecoder decodeObjectForKey:@"imageDataDic"];
        self.imageArray = [aDecoder decodeObjectForKey:@"imageArray"];
        
    }
    return self;
}

@end

