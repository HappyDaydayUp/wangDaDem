//
//  FolioReaderKit.h
//  FolioReaderKit
//
//  Created by Alex Popov on 2016-06-04.
//  Copyright © 2016 FolioReader. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FolioReaderKit.
FOUNDATION_EXPORT double FolioReaderKitVersionNumber;

//! Project version string for FolioReaderKit.
FOUNDATION_EXPORT const unsigned char FolioReaderKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FolioReaderKit/PublicHeader.h>


