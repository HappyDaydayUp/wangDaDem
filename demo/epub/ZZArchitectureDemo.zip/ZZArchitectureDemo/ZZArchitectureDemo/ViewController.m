//
//  ViewController.m
//  ZZArchitectureDemo
//
//  Created by oldliu on 2020/4/27.
//  Copyright © 2020 oldliu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<ZZBaseViewControllerProtocol>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor redColor];
}
- (void)zz_addSubviews{
    
}
@end
