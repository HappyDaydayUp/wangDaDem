//
//  BaseModel.m
//  ZZArchitectureDemo
//
//  Created by oldliu on 2020/5/7.
//  Copyright © 2020 oldliu. All rights reserved.
//

#import "BaseModel.h"

@implementation BaseModel

@end
