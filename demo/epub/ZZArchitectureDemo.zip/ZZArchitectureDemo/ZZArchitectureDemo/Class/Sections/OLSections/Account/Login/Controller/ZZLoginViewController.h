//
//  ZZLoginViewController.h
//  ZZArchitectureDemo
//
//  Created by oldliu on 2020/5/8.
//  Copyright © 2020 oldliu. All rights reserved.
//

#import "ZZBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZZLoginViewController : ZZBaseViewController

@end

NS_ASSUME_NONNULL_END
