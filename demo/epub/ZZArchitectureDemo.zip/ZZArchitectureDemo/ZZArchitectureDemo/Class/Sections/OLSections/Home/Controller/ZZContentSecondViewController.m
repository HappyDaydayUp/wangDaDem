//
//  ZZContentSecondViewController.m
//  ZZArchitectureDemo
//
//  Created by oldliu on 2020/4/29.
//  Copyright © 2020 oldliu. All rights reserved.
//

#import "ZZContentSecondViewController.h"

@interface ZZContentSecondViewController ()

@end

@implementation ZZContentSecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


- (UIView *)listView {
    return self.view;
}
@end
