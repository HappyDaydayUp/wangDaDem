//
//  ZZHomeViewController.h
//  ZZArchitectureDemo
//
//  Created by oldliu on 2020/4/29.
//  Copyright © 2020 oldliu. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZZHomeViewController : ZZBaseViewController

@end

NS_ASSUME_NONNULL_END
