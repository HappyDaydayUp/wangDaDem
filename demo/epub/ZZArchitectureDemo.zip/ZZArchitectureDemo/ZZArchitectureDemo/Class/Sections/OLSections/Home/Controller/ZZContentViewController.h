//
//  ZZContentViewController.h
//  ZZArchitectureDemo
//
//  Created by oldliu on 2020/4/29.
//  Copyright © 2020 oldliu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JXPagerView.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZZContentViewController : UIViewController<JXPagerViewListViewDelegate>

@end

NS_ASSUME_NONNULL_END
