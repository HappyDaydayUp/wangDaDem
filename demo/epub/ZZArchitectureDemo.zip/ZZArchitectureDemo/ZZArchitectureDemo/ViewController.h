//
//  ViewController.h
//  ZZArchitectureDemo
//
//  Created by oldliu on 2020/4/27.
//  Copyright © 2020 oldliu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZZBaseViewController.h"
@interface ViewController : ZZBaseViewController


@end

