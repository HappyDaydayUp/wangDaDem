//
//  AppDelegate.h
//  ZZArchitectureDemo
//
//  Created by oldliu on 2020/4/27.
//  Copyright © 2020 oldliu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow * window;


@end

