//
//  CMoudle.m
//  ZZArchitectureDemo
//
//  Created by oldliu on 2020/4/28.
//  Copyright © 2020 oldliu. All rights reserved.
//

#import "CModule.h"

@implementation CModule
-(BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary<UIApplicationLaunchOptionsKey,id> *)launchOptions{
    NSLog(@"CMOULDE");
    return YES;
}

@end
